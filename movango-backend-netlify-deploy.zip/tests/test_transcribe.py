import pytest
from fastapi.testclient import TestClient
from app.main import app
import io

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

def test_transcribe_invalid_file():
    response = client.post("/transcribe", data={"user_id": "user1"}, files={"file": ("test.txt", io.BytesIO(b"dummy"), "text/plain")})
    assert response.status_code == 400

@pytest.fixture(autouse=True)
def mock_openai_and_supabase(monkeypatch):
    # Mock Whisper transcription
    class MockAudio:
        @staticmethod
        def transcribe(model, file, response_format):
            return {"text": "olá mundo"}
    monkeypatch.setattr("openai.Audio", MockAudio)
    # Mock Supabase client
    class MockClient:
        def __init__(self, *args, **kwargs): pass
        def from_(self, table):
            return self
        def insert(self, data):
            self._data = data
            return self
        def execute(self):
            return {"data": [{"id": 123}], "error": None}
    # Point the supabase instance used in the route to our mock
    import app.routes.transcribe as mod
    mod.supabase = MockClient()
    yield

def test_transcribe_success(tmp_path):
    # Create dummy wav file
    file_path = tmp_path / "test.wav"
    file_path.write_bytes(b"RIFF....WAVEfmt ")
    with open(file_path, "rb") as f:
        response = client.post(
            "/transcribe",
            data={"user_id": "user1"},
            files={"file": ("test.wav", f, "audio/wav")}
        )
    assert response.status_code == 200
    json_resp = response.json()
    assert json_resp["status"] == "success"
    assert json_resp["transcription"] == "olá mundo"
    assert json_resp["record_id"] == 123
