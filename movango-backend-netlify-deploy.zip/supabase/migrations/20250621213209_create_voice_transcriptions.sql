-- Migration: Create voice_transcriptions table
CREATE TABLE public.voice_transcriptions (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id TEXT NOT NULL,
  filename TEXT NOT NULL,
  transcription TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.voice_transcriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY allow_insert_transcriptions
  ON public.voice_transcriptions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);
