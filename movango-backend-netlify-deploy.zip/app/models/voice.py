from pydantic import BaseModel
from datetime import datetime

class VoiceTranscription(BaseModel):
    id: int
    user_id: str
    filename: str
    transcription: str
    created_at: datetime
