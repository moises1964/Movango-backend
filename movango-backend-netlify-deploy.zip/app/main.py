from app.routes.transcribe import router as transcribe_router
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

app = FastAPI(
app.include_router(transcribe_router)

    title="MOVANGO API",
    description="Backend para o aplicativo de mobilidade e reboque MOVANGO",
    version="0.1.0"
)

# CORS configuration
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health", tags=["health"])
async def health_check():
    return {"status": "ok"}
