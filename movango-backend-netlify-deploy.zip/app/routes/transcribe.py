from fastapi import APIRouter, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
import aiofiles
import os
import openai
from supabase import create_client
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

openai.api_key = OPENAI_API_KEY
supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

router = APIRouter(prefix="", tags=["transcription"])

@router.post("/transcribe")
async def transcribe_audio(user_id: str, file: UploadFile = File(...)):
    if not file.content_type.startswith("audio/"):
        raise HTTPException(400, detail="Arquivo de áudio inválido.")

    temp_path = f"/tmp/{file.filename}"
    async with aiofiles.open(temp_path, "wb") as out_file:
        content = await file.read()
        await out_file.write(content)

    try:
        whisper_resp = openai.Audio.transcribe(
            model="whisper-1",
            file=open(temp_path, "rb"),
            response_format="json"
        )
        text = whisper_resp.get("text", "")

        data = {
            "user_id": user_id,
            "filename": file.filename,
            "transcription": text
        }
        resp = supabase.from_("voice_transcriptions").insert(data).execute()

        if resp.get("error"):
            raise Exception(resp["error"]["message"])

        return JSONResponse({
            "status": "success",
            "transcription": text,
            "record_id": resp["data"][0]["id"]
        })
    except Exception as e:
        raise HTTPException(500, detail=str(e))
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)
